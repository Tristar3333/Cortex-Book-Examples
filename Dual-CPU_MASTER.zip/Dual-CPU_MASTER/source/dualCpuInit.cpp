#include <string.h>
#include <fsl_debug_console.h>

#include "dualCpuInit.h"

///////////////////////////////////////////////////////////////////////////////

void dualCpuInit( void )
{
   AHBCLKCTRL0SET = ((1 << 13) | (1 << 15)); // Enable clock for IOCON and GPIO0
   PRESETCTRL0SET = (1 << 13);               // Activate reset for GPIO0
   PRESETCTRL0CLR = (1 << 13);               // Release reset for GPIO0
                                             // Configure pin PIO0_20 (GPIO0_20)
   IOCONPIO0_20   = (1 << 8);                // FUNC = 0 (GPIO)
   GPIOPORT0CLR   = (1 << 20);               // Set pin to 0
   GPIODIR0SET    = (1 << 20);               // Set pin to output
}
