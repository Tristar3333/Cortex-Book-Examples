#ifndef __VENEERS_H__
#define __VENEERS_H__

typedef bool (*pCallBack)(void) __attribute__((cmse_nonsecure_call));

void setLED( bool setON );

bool setSwitchHandler( pCallBack func );

#endif // __VENEERS_H__
