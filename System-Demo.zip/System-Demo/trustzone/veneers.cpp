#if (__ARM_FEATURE_CMSE & 1) == 0
#error "Need ARMv8-M security extensions"
#elif (__ARM_FEATURE_CMSE & 2) == 0
#error "Compile with --cmse"
#endif

#include "stdint.h"
#include "arm_cmse.h"
#include "fsl_debug_console.h"

#include "veneers.h"
#include "sysFuncs.h"
                                       // Function callable for NS software
__attribute__((cmse_nonsecure_entry)) void setLED( bool setON )
{
   sysSetLED( setON );                 // Call system function for switching LED
}
