#ifndef __INIT_TRUST_ZONE__
#define __INIT_TRUST_ZONE__

/* Initialize TrustZone */
void BOARD_InitTrustZone();

#endif // __INIT_TRUST_ZONE__
