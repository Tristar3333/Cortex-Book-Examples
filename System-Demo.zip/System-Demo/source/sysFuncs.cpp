#include "gpioDefs.h"
#include "veneers.h"
#include "sysFuncs.h"

void toggle( void );                         // Defined in NS area

//void intLatInit( void )
//{                                            // Enable clock for IMUX, IOCON, GPIO1, PINT
//   AHBCLKCTRL0SET = ((1 << 18) | (1 << 15) | (1 << 13) | (1 << 11));
//                                             // Configure pins PIO1_9 (Input), PIO1_6 (Output)
//   IOCONPIO1_9 = (1 << 8);                   // GPIO mode, digital mode
//   IOCONPIO1_6 = (1 << 8);                   // GPIO mode, digital mode
//                                             // Configure GPIO pins
//   GPIOPORT1SET = (1 << 6);                  // Set pin P1_6 to 1
//   GPIODIR1CLR  = (1 << 9);                  // Configure pin P1_9 as input
//   GPIODIR1SET  = (1 << 6);                  // Configure pin P1_6 as output LED
//
//   IMUX_PINTSEL0 = (32 + 9);                 // Set pin P1_9 as PININT0
//   
//   PININT->ISEL = (PININT->ISEL & ~(1 << 0));// Pin interrupt mode = edge sensitive
//   PININT->SIENF = (1 << 0);                 // Enable on falling edge of int pin 0
//   NVIC_ISER0 = (1 << 4);                    // Enable pin interrupt 0 in NVIC
//}

void sysInitSwitchAndLED( void )
{                                            // Configure red LED on port PIO1_4
   AHBCLKCTRL0SET = (1 << 13);               // Enable clock for IOCON
   AHBCLKCTRL1SET = (1 << 15);               // Enable clock for GPIO1
   PRESETCTRL1SET = (1 << 13);               // Activate reset for GPIO1
   PRESETCTRL1CLR = (1 << 13);               // Release reset for GPIO1
                                             // Configure pin PIO1_4 (GPIO1_4)
   IOCONPIO1_4    = (1 << 8);                // DIGIMODE = 1, FUNC = 0 (GPIO)
   GPIOPORT1SET   = (1 << 4);                // Set pin to 1 (switch LED off)
   GPIODIR1SET    = (1 << 4);                // Set pin to output
                                             // Configure pin PIO1_9 (GPIO1_9)
   IOCONPIO1_9    = (1 << 8);                // GPIO mode, digital mode
   GPIODIR1CLR    = (1 << 9);                // Configure pin P1_9 as input
}

void sysSetLED( bool setON )
{
   if( setON )
   {
      GPIOPORT1CLR = (1 << 4);               // Set pin to 0
   }
   else
   {
      GPIOPORT1SET = (1 << 4);               // Set pin to 1
   }
}

void sysGpioIntHandler( void )
{
//   toggle();
}
