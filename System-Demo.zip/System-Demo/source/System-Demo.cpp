#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "LPC55S69_cm33_core0.h"
#include "fsl_debug_console.h"
/* TODO: insert other include files here. */
#include "InitTrustZone.h"
#include "sysFuncs.h"

/* TODO: insert other definitions and declarations here. */

#define DEMO_CODE_START_NS 0x00010000
#define NON_SECURE_START DEMO_CODE_START_NS

/* typedef for non-secure callback functions */
typedef void (*funcPtr)(void) __attribute__((cmse_nonsecure_call));

void main(void) __attribute__ ((noreturn));

void SystemInitHook(void)
{
    /* The TrustZone should be configured as early as possible after RESET.
     * Therefore it is called from SystemInit() during startup. The SystemInitHook() weak function
     * overloading is used for this purpose.
     */
    BOARD_InitTrustZone();
}

void main(void)
{
   funcPtr pResetHandlerNS;      // Pointer to NS software to be called

   BOARD_InitPins();             // Default initialization
   BOARD_BootClockPLL150M();     // Set clock to 150 MHz
   sysInitSwitchAndLED();        // Init LED and switch pins and interrupt
                                 // Set non-secure main stack (MSP_NS)
   __TZ_set_MSP_NS(*((uint32_t *)(NON_SECURE_START)));
                                 // Set non-secure vector table
   SCB_NS->VTOR = NON_SECURE_START;
                                 // Get non-secure reset handler
   pResetHandlerNS = (funcPtr)(*((uint32_t *)((NON_SECURE_START) + 4U)));

   pResetHandlerNS();            // Jump to normal world
   while(1)
   {
     __asm volatile ("nop");
   }
}
