#ifndef __SYS_FUNCTIONS_H__
#define __SYS_FUNCTIONS_H__

void sysInitSwitchAndLED( void );

void sysSetLED( bool setON );                // System function to switch LED

extern "C" void sysGpioIntHandler( void );   // GPIO interrupt handler

#endif // __SYS_FUNCTIONS_H__
