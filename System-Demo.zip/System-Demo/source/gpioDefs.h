#include "stdint.h"

#define AHBCLKCTRL0SET   (*((uint32_t volatile *)0x50000220)) 
#define AHBCLKCTRL1SET   (*((uint32_t volatile *)0x50000224))
#define PRESETCTRL1SET   (*((uint32_t volatile *)0x50000124))
#define PRESETCTRL1CLR   (*((uint32_t volatile *)0x50000144))
#define IOCONPIO1_4      (*((uint32_t volatile *)0x50001090)) 
#define IOCONPIO1_9      (*((uint32_t volatile *)0x500010A4))
#define GPIOPORT1SET     (*((uint32_t volatile *)0x5008E204)) 
#define GPIOPORT1CLR     (*((uint32_t volatile *)0x5008E284))
#define GPIODIR1SET      (*((uint32_t volatile *)0x5008E384))
#define GPIODIR1CLR      (*((uint32_t volatile *)0x5008E404)) 