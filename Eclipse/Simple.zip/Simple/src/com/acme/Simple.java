package com.acme;

import javacard.framework.APDU;
import javacard.framework.Applet;
import javacard.framework.ISO7816;
import javacard.framework.ISOException;
import javacard.framework.Util;

public class Simple extends Applet
{
	public final static byte CLA = (byte)0x80;
	public final static byte INS_ADD = (byte)0x01;
	
	private short m_sValue = 0;  // Internal value to change
	
	public static void install( byte[] bArray, short bOffset, byte bLength )
	{		                     // GP-compliant JavaCard applet registration
		new Simple().register( bArray, (short)(bOffset + 1 ), bArray[bOffset]);
	}

	public void process( APDU apdu )
	{		                     // Good practice: Return 9000 on SELECT
		if( selectingApplet() )
		{
			return;
		}

		final byte[] buf = apdu.getBuffer();
		
		if( CLA != buf[ISO7816.OFFSET_CLA] )
		{                        // CLA byte must be 0x80!
			ISOException.throwIt( ISO7816.SW_CLA_NOT_SUPPORTED );
		}
		switch( buf[ISO7816.OFFSET_INS] )
		{
		case INS_ADD:            // Add parameter P1 to value
			add( apdu );
			break;
		
		default: 			     // good practice: If you don't know the INStruction, say so:
			ISOException.throwIt( ISO7816.SW_INS_NOT_SUPPORTED );
		}
	}
	
	private void add( APDU apdu )
	{
		byte[] buffer = apdu.getBuffer();
		                         // Read parameter P1 to add to the value
		m_sValue += buffer[ISO7816.OFFSET_P1];
		                         // The buffer is used for response data
		                         // First two bytes changed value
        Util.setShort( buffer, (short)0, m_sValue );
                                 // Last two bytes status code (0x9000)
        Util.setShort( buffer, (short)2, ISO7816.SW_NO_ERROR );
                                 // Sending the byte back to caller
        apdu.setOutgoingAndSend( (short)0, (short)4 );
	}
}
