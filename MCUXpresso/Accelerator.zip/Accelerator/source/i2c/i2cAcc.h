#ifndef __I2C_ACC_H__
#define __I2C_ACC_H__

#include <cstdint>

// Definition of completion function pointer.
typedef void (*pCompletion)(uint32_t);

/**
   \fn      void i2cAccInit(void)
   \brief   Initialize I2C interface on Flexcomm4 port.
*/
extern "C" void i2cAccInit( void );

/**
   \fn      uint32_t i2cAccRead( uint8_t addr, uint8_t *pData, uint32_t size )
   \brief   Read data from I2C interface on Flexcomm4 port.
   \param   addr  Register address to read
   \param   pData Pointer to user buffer for reading bytes.
   \param   size  Size of user data buffer in bytes.
   \param   pFunc Pointer to completion function (might be null).
   \return  0 if no error occurs, 1 if oneof the parameters is null.
*/
extern "C" uint32_t i2cAccRead( uint8_t addr, uint8_t *pData, uint32_t size, pCompletion pFunc = 0 );

/**
   \fn      uint32_t i2cAccWrite( uint8_t addr, uint8_t *pData, uint32_t size )
   \brief   Write data to I2C interface on Flexcomm4 port.
   \param   addr  Register address to write.
   \param   data Date byte to write.
   \param   pFunc Pointer to completion function (might be null).
   \return  0 if no error occurs, 1 if oneof the parameters is null.
*/
extern "C" uint32_t i2cAccWrite( uint8_t addr, uint8_t data, pCompletion pFunc = 0 );

#endif // __I2C_ACC_H__
