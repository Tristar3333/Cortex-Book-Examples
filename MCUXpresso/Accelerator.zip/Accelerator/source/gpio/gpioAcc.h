#ifndef __GPIO_ACC_H__
#define __GPIO_ACC_H__

#include <cstdint>

// Definition of service function pointer for PIN interrupts.
typedef void (*pPinFunc)(void);

/**
   \fn      void gpioAccInit(void)
   \brief   Initialize GPIO interrupt for accelerator pin interrupt.
*/
extern "C" void gpioAccInit( pPinFunc funcPtr );

#endif // __GPIO_ACC_H__
