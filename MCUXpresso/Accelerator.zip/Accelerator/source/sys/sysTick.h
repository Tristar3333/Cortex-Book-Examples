/**
   \file       sysTick.h
   \brief      Definition of the system tick counter functions.
   \author     Wolfgang Kramper
   \date       25.10.2016
   \copyright  NXP Semiconductors. All rights reserved.
*/

#ifndef __SYS_TICK_H__
#define __SYS_TICK_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

void sysClockGen( void );

void sysTickInit( void );

uint32_t sysTick32( void );

uint64_t sysTick64( void );

void sysSleep( int32_t timeMS );

void sysWait( void );

void sysEnableInterrupt( uint8_t set );

uint32_t sysDivideBy10( uint32_t divided ) __attribute__ ((pure));

#ifdef __cplusplus
}
#endif

#endif // __SYS_TICK_H__
