/*
 * Copyright 2016-2022 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file    Accelerator.cpp
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "LPC55S69_cm33_core0.h"
#include "fsl_debug_console.h"

#include "i2c/i2cAcc.h"                   // I2C controller functions
#include "gpio/gpioAcc.h"
#include "i2c/mma8652fc.h"                // MMA8652FC register definitions
#include "sys/sysTick.h"                  // SysTick timer functions

int main( void ) 
{
   const int ciNumValues = 512;             // Number of datasets to acquire
   int iValueCount = 0;                   // Loop counter
   uint8_t buffer[8];                     // Input buffer for I2C data
   static int16_t values[ciNumValues][3]; // Result buffer for all acceleration values

   BOARD_InitBootPins();                  // Init board hardware.
   BOARD_InitBootClocks();
   BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
   BOARD_InitDebugConsole();              // Init FSL debug console.
#endif

   sysTickInit();                         // Init SysTick timer
   i2cAccInit();                          // Init I2C bus interface to accelerator

   sysEnableInterrupt( 1 );               // Release system interrupts
                                    
   i2cAccWrite( CTRL_REG1, 0x00 );        // Disable ACTIVE mode
   sysSleep( 2 );                         // Wait 5 ms
   i2cAccWrite( XYZ_DATA_CFG_REG, 0x00 ); // Full range +/- 2 g
   sysSleep( 2 );
   i2cAccWrite( CTRL_REG2, 0x02 );        // High resolution mode
   sysSleep( 2 );
   i2cAccWrite( CTRL_REG3, 0x00 );        // Push/pull active low
   sysSleep( 2 );
   i2cAccWrite( CTRL_REG4, 0x01 );        // Enable DRY interrupt
   sysSleep( 2 );
   i2cAccWrite( CTRL_REG5, 0x01 );        // DRY interrupt to INT1
   sysSleep( 2 );
   i2cAccWrite( CTRL_REG1, 0x19 );        // Date rate = 10 ms, enable ACTIVE mode
   sysSleep( 20 );

   while( 1 )
   {
      if( iValueCount < ciNumValues )
      {                                   // Fill buffer 'values'
         i2cAccRead( STATUS_REG, buffer, 7 );
         if( (buffer[0] & 0x0f) == 0x0f )
         {                                // x value
            values[iValueCount][0] = int16_t((buffer[1] << 8) | (buffer[2] & 0x0ff)) >> 4;
                                          // y value
            values[iValueCount][1] = int16_t((buffer[3] << 8) | (buffer[4] & 0x0ff)) >> 4;
                                          // z value
            values[iValueCount][2] = int16_t((buffer[5] << 8) | (buffer[6] & 0x0ff)) >> 4;
            iValueCount++;
            sysSleep( 12 );               // Wait for acquire new values
         }
         else
         {
            sysSleep( 2 );                // Data not ready yet -> wait
         }
      }
      else
      {
         i2cAccWrite( CTRL_REG1, 0x00 );  // Disable ACTIVE mode
         break;
      }
   }

   for( int i = 0; i < ciNumValues; i++ )
   {                                      // Print all values into debug console
      PRINTF( "%d, %d, %d, %d\n", i, values[i][0], values[i][1], values[i][2] );
   }

   while(1)
   {
      sysWait();
   }

   return 0 ;
}
