#ifndef __VENEER_ENTRIES_H__
#define __VENEER_ENTRIES_H__

typedef bool (*pCallBack)(void);

void setLED( bool setON );

bool setSwitchHandler( pCallBack func );

#endif // __VENEER_ENTRIES_H__
