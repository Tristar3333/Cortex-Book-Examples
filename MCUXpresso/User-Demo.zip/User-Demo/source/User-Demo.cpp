#include <stdio.h>
#include "LPC55S69_cm33_core0.h"
#include "veneerEntries.h"            // Definition of verneer handlers

void main(void) __attribute__ ((noreturn));

static bool g_bValue = false;
static int g_iChanged = 0;

void toggle( void )
{
   g_bValue = ! g_bValue;
   g_iChanged = 1;
}

void main(void)
{
   setLED( false );              // Switch LED off

   while(1)
   {                             // Cannot leave NS state again
      if( g_iChanged )
      {
         setLED( g_bValue );
         g_iChanged = 0;
      }

      __asm volatile ("nop");
   }
}
