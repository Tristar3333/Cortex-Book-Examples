#ifndef __DUAL_CPU_INIT_H__
#define __DUAL_CPU_INIT_H__

#include <stdint.h>
                        // AHB clock control set register
#define AHBCLKCTRL0SET   (*((uint32_t volatile *)0x50000220)) 
                        // Peripheral reset set register
#define PRESETCTRL0SET     (*((uint32_t volatile *)0x50000120))
                        // Peripheral reset clear register
#define PRESETCTRL0CLR     (*((uint32_t volatile *)0x50000140))
                        // I/O Configuration base register, Digital I/O control for port 1 pins
#define IOCONPIO0_21     (*((uint32_t volatile *)0x40001054)) 
                        // GPIO port and direction registers
#define GPIOPORT0SET     (*((uint32_t volatile *)0x4008E200))
#define GPIOPORT0CLR     (*((uint32_t volatile *)0x4008E280))
#define GPIODIR0SET      (*((uint32_t volatile *)0x4008E380))

void dualCpuInit( void );

#endif // __DUAL_CPU_INIT_H__
