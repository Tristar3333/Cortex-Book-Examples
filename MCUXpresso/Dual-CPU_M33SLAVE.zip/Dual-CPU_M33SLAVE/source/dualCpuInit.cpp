#include <string.h>
#include <fsl_debug_console.h>

#include "dualCpuInit.h"

///////////////////////////////////////////////////////////////////////////////

void dualCpuInit( void )
{                                            // Configure pin PIO0_21 (GPIO0_20)
   IOCONPIO0_21   = (1 << 8);                // FUNC = 0 (GPIO)
   GPIOPORT0CLR   = (1 << 21);               // Set pin to 0
   GPIODIR0SET    = (1 << 21);               // Set pin to output
}
