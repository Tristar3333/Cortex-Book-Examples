#include <string.h>
#include <fsl_debug_console.h>

#include "sct.h"

///////////////////////////////////////////////////////////////////////////////

void sctInit( void )
{
   CTIMERCLKSEL1SET = 3;                     // Set FRO 96 MHz clock for TIMER1
   AHBCLKCTRL0SET = (1 << 13);               // Enable clock for I/O Controller
   AHBCLKCTRL1SET = (1 << 27);               // Enable clock for TIMER1
   PRESETCTRL1SET = (1 << 27);               // Activate reset for TIMER1
   PRESETCTRL1CLR = (1 << 27);               // Release reset for TIMER1
                                             // Configure pin PIO0_20 (CT1_MAT1)
   IOCONPIO0_20 = ((1 << 8) | 2);            // DIGIMODE = 1, FUNC = 2

   TIMER1->TCR  = 0;                         // Disable timer
   TIMER1->IR   = 0;                         // No interrupts
   TIMER1->PR   = 0;                         // Pre-scaler not used
   TIMER1->MCR  = (1 << 4);                  // Reset on MR1
   TIMER1->MR1  = 0x0BB7F;                   // Match value 2 (for 1 kHz)
   TIMER1->MR0  = 0xFFFFFFFF;	               // Match value 0 not used
   TIMER1->MR2  = 0xFFFFFFFF;	               // Match value 1 not used
   TIMER1->MR3  = 0xFFFFFFFF;	               // Match value 3 not used
   TIMER1->CTCR = 0;                         // Timer mode
   TIMER1->EMR  = (3 << 6);                  // Toggle external match 1
   TIMER1->TCR  = 2;                         // Reset counter and pre-scale counter
   TIMER1->TCR  = 1;                         // Enable timer
}
