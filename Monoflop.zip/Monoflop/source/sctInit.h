#ifndef __SCT__INIT_PLU_EXAMPLE_H__
#define __SCT__INIT_PLU_EXAMPLE_H__

void sctInit( void );

#endif // __SCT__INIT_PLU_EXAMPLE_H__
