#ifndef __PLU_PLU_EXAMPLE_H__
#define __PLU_PLU_EXAMPLE_H__

#include "LPC55S69_cm33_core0.h"

                        // AHB clock control set register
#define AHBCLKCTRL2SET   (*((uint32_t volatile *)0x50000228)) 
                        // Peripheral reset set register
#define PRESETCTRL2SET   (*((uint32_t volatile *)0x50000128)) 
                        // Peripheral reset clear register
#define PRESETCTRL2CLR   (*((uint32_t volatile *)0x50000148)) 
                        // I/O Configuration base register, Digital I/O control for port 1 pins
#define IOCONPIO0_19     (*((uint32_t volatile *)0x4000104C))
#define IOCONPIO0_21     (*((uint32_t volatile *)0x40001054)) 
#define IOCONPIO0_27     (*((uint32_t volatile *)0x4000106C)) 

#endif // __PLU_PLU_EXAMPLE_H__
