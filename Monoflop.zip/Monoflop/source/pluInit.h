#ifndef __PLU__INIT_PLU_EXAMPLE_H__
#define __PLU__INIT_PLU_EXAMPLE_H__

void pluInit( void );

#endif // __PLU__INIT_PLU_EXAMPLE_H__
