#ifndef __SCT_PLU_EXAMPLE_H__
#define __SCT_PLU_EXAMPLE_H__

                        // CTimer 1 clock source select
#define CTIMERCLKSEL1SET (*((uint32_t volatile *)0x50000270))
                        // AHB clock control set 1, 2 register
#define AHBCLKCTRL0SET   (*((uint32_t volatile *)0x50000220)) 
#define AHBCLKCTRL1SET   (*((uint32_t volatile *)0x50000224)) 
                        // Peripheral reset control 1 set
#define PRESETCTRL1SET   (*((uint32_t volatile *)0x50000124)) 
                        // Peripheral reset control 1 clear
#define PRESETCTRL1CLR   (*((uint32_t volatile *)0x50000144)) 
                        // I/O Configuration base register, Digital I/O control for port 1 pins
#define IOCONPIO0_20     (*((uint32_t volatile *)0x40001050))

typedef struct
{
   uint32_t IR;         // Interrupt Register
   uint32_t TCR;        // Timer Control Register
   uint32_t TC;         // Timer Counter
   uint32_t PR;         // Pre-scale Register
   uint32_t PC;         // Pre-scale Counter
   uint32_t MCR;        // Match Control Register
   uint32_t MR0;        // Match Register 0
   uint32_t MR1;        // Match Register 1
   uint32_t MR2;        // Match Register 2
   uint32_t MR3;        // Match Register 3
   uint32_t CCR;        // Capture Control Register
   uint32_t CR0;        // Capture Register 0 (read only)
   uint32_t CR1;        // Capture Register 1 (read only)
   uint32_t CR2;        // Capture Register 2 (read only)
   uint32_t CR3;        // Capture Register 3 (read only)
   uint32_t EMR;        // External Match Register
   uint32_t __DUMMY[12];// Dummy for address offset (not to be used)
   uint32_t CTCR;       // Count Control Register
   uint32_t PWMC;       // PWM Control Register
   uint32_t MSR0;       // Match 0 Shadow Register
   uint32_t MSR1;       // Match 1 Shadow Register
   uint32_t MSR2;       // Match 2 Shadow Register
   uint32_t MSR3;       // Match 3 Shadow Register
} 
CTimer_t;
                        // Counter/Timer 1 base address
volatile CTimer_t *const TIMER1 = (CTimer_t *)0x40009000;

#endif // __SCT_PLU_EXAMPLE_H__
