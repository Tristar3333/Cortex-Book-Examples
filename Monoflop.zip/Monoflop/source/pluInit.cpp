#include <string.h>
#include <fsl_debug_console.h>

#include "plu.h"

///////////////////////////////////////////////////////////////////////////////

void pluInit( void )
{
   AHBCLKCTRL2SET = (1 << 20);               // Enable clock for PLU
   PRESETCTRL2SET = (1 << 20);               // Activate reset for PLU
   PRESETCTRL2CLR = (1 << 20);               // Release reset for PLU
                                             // Configure pin PIO0_19 (PLU_IN4)
   IOCONPIO0_19 = ((1 << 8) | 9);            // FUNC = 9
                                             // Configure pin PIO0_21 (PLU_CLKIN)
   IOCONPIO0_21 = ((1 << 8) | 9);            // FUNC = 9
                                             // Configure pin PIO0_27 (PLU_OUT0)
   IOCONPIO0_27 = ((1 << 8) | 9);            // FUNC = 9

   #include "../excluded/plu_tool.c"         // Load file created by PLU Config Tool
}
